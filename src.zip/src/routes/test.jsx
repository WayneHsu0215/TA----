import React, {useEffect, useState} from 'react';
import {Icon} from '@iconify/react';
import Header from './Header';


function Test() {

    return (
        <div className="container mx-auto">
            <Header />
            <div>test</div>
        </div>


    );

}

export default Test;
